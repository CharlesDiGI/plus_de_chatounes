**To enable a user**

This example enables username jane@example.com.

Command::

  aws cognito-idp admin-enable-user --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com

